#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<Windows.h>
#include<ShlObj.h>
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
struct control_version
{
	bool Win10;
	bool Win8;
	bool Win7;
	bool Vista;
	bool other;
}ver;

void getVersion()
{
	typedef void(NTAPI* PRtlGetNtVersionNumbers)(DWORD*, DWORD*, DWORD*);
	HMODULE ntdll = LoadLibrary(L"ntdll.dll");
	PRtlGetNtVersionNumbers RtlGetNtVersionNumbers = (PRtlGetNtVersionNumbers)GetProcAddress(ntdll, "RtlGetNtVersionNumbers");
	DWORD Major, Minor, BuildNumber;
	RtlGetNtVersionNumbers(&Major, &Minor, &BuildNumber);
	if (Major == 10 && Minor == 0)ver.Win10 = true;
	if (Major == 6 && Minor == 3 || Major == 6 && Minor == 2)ver.Win8 = true;
	if (Major == 6 && Minor == 1)ver.Win7 = true;
	if (Major == 6 && Minor == 0)ver.Vista = true;
	if (ver.Win10 != true && ver.Win8 != true && ver.Win7 != true && ver.Vista != true) ver.other = true;
}

typedef enum _WINDOWCOMPOSITIONATTRIB
{
	WCA_UNDEFINED = 0,
	WCA_NCRENDERING_ENABLED = 1,
	WCA_NCRENDERING_POLICY = 2,
	WCA_TRANSITIONS_FORCEDISABLED = 3,
	WCA_ALLOW_NCPAINT = 4,
	WCA_CAPTION_BUTTON_BOUNDS = 5,
	WCA_NONCLIENT_RTL_LAYOUT = 6,
	WCA_FORCE_ICONIC_REPRESENTATION = 7,
	WCA_EXTENDED_FRAME_BOUNDS = 8,
	WCA_HAS_ICONIC_BITMAP = 9,
	WCA_THEME_ATTRIBUTES = 10,
	WCA_NCRENDERING_EXILED = 11,
	WCA_NCADORNMENTINFO = 12,
	WCA_EXCLUDED_FROM_LIVEPREVIEW = 13,
	WCA_VIDEO_OVERLAY_ACTIVE = 14,
	WCA_FORCE_ACTIVEWINDOW_APPEARANCE = 15,
	WCA_DISALLOW_PEEK = 16,
	WCA_CLOAK = 17,
	WCA_CLOAKED = 18,
	WCA_ACCENT_POLICY = 19,
	WCA_FREEZE_REPRESENTATION = 20,
	WCA_EVER_UNCLOAKED = 21,
	WCA_VISUAL_OWNER = 22,
	WCA_LAST = 23
} WINDOWCOMPOSITIONATTRIB;

typedef struct _WINDOWCOMPOSITIONATTRIBDATA
{
	WINDOWCOMPOSITIONATTRIB Attrib;
	PVOID pvData;
	SIZE_T cbData;
} WINDOWCOMPOSITIONATTRIBDATA;

typedef enum _ACCENT_STATE
{
	ACCENT_DISABLED = 0,
	ACCENT_ENABLE_GRADIENT = 1,
	ACCENT_ENABLE_TRANSPARENTGRADIENT = 2,
	ACCENT_ENABLE_BLURBEHIND = 3,
	ACCENT_ENABLE_ACRYLICBLURBEHIND = 4,
	ACCENT_INVALID_STATE = 5
} ACCENT_STATE;

typedef struct _ACCENT_POLICY
{
	ACCENT_STATE AccentState;
	DWORD AccentFlags;
	DWORD GradientColor;
	DWORD AnimationId;
} ACCENT_POLICY;
LPCWSTR CharToWchar(const char* str)
{
	WCHAR str1[256] = { 0 };
	memset(str1, 0, sizeof(str1));
	MultiByteToWideChar(CP_ACP, 0, str, strlen(str) + 1, str1, sizeof(str1) / sizeof(str1[0]));
	return str1;
}
BOOL QueryServiceState()
{
	SC_HANDLE sc = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	SC_HANDLE Ser = OpenServiceW(sc, L"Aero Pro", SERVICE_ALL_ACCESS);
	if (Ser == NULL) return FALSE;
	else return TRUE;
}
void AutoStart()
{
	if (QueryServiceState() == FALSE)
	{
		MessageBox(NULL, L"���ڴ˹��ܸ�д��������δ������ȫ�Ĳ��ԣ��������û��������\n�뷴��������QQ:524667630,лл��\n", L"Aero Pro", MB_ICONWARNING);
		if (IsUserAnAdmin() != true)
		{
			MessageBox(NULL, L"���Ŀǰ����δ�ù���ԱȨ������\n���Զ��˳�������ʹ�ù���ԱȨ�����б�����\n", L"Aero Pro", MB_ICONWARNING);
			exit(0);
		}
		MessageBox(NULL, L"����ʵ����������Ҫ�ѱ�����ע��Ϊһ������\n����ȷ���Ժ�Ҫһֱ�ƶ��������λ��\n", L"Aero Pro", MB_ICONINFORMATION);
		SC_HANDLE sc = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		WCHAR Path[MAX_PATH] = { 0 };
		memset(Path, 0, sizeof(Path));
		MultiByteToWideChar(CP_ACP, 0, _pgmptr, strlen(_pgmptr) + 1, Path, sizeof(Path) / sizeof(Path[0]));
		SC_HANDLE Service = CreateServiceW(sc, L"Aero Pro", L"Aero Pro", SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS, SERVICE_AUTO_START, SERVICE_ERROR_NORMAL, Path, NULL, NULL, NULL, NULL, NULL);
		StartService(Service, NULL, NULL);
		MessageBox(NULL, L"�����û�н��а�������Ļ�\n�����Ѿ��ɹ�������\n��������ʱɾ�������񣬷�������Aero Pro", L"Aero Pro", MB_ICONINFORMATION);
	}
	else
	{
		if (MessageBox(NULL, L"���Ѿ��ɹ�ע�᱾�����Ƿ�Ҫж�ط���", L"Aero Pro", MB_ICONINFORMATION | MB_YESNO) == 6)
		{
			if (IsUserAnAdmin() != true)
			{
				MessageBox(NULL, L"���Ŀǰ����δ�ù���ԱȨ������\n���Զ��˳�������ʹ�ù���ԱȨ�����б�����\n", L"Aero Pro", MB_ICONWARNING);
				exit(0);
			}
			SC_HANDLE sc = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
			SC_HANDLE Ser = OpenServiceW(sc, L"Aero Pro", SERVICE_ALL_ACCESS);
			SERVICE_STATUS st;
			ControlService(Ser, SERVICE_STOP, &st);
			DeleteService(Ser);
			MessageBox(NULL, L"�����û�н��а�������Ļ�\n�����ѳɹ��Ƴ�\n��������ʱ���¿�������", L"Aero Pro", MB_ICONINFORMATION);
		}
		else
		{
			MessageBoxW(NULL, L"�ѳɹ���ֹ����", L"Aero Pro",MB_ICONINFORMATION);
		}
	}
}
void EnableAeroPro(HWND hwnd)
{
	ACCENT_POLICY accent = { ACCENT_ENABLE_BLURBEHIND,0,0,0 };
	WINDOWCOMPOSITIONATTRIBDATA data;
	data.Attrib = WCA_ACCENT_POLICY;
	data.pvData = &accent;
	data.cbData = sizeof(accent);
	HMODULE user32 = LoadLibrary(L"user32.dll");
	typedef BOOL(WINAPI* PtrSetWindowCompositionAttribute)(HWND hwnd, WINDOWCOMPOSITIONATTRIBDATA* pAttribute);
	PtrSetWindowCompositionAttribute SetWindowCompositionAttribute = (PtrSetWindowCompositionAttribute)GetProcAddress(user32, "SetWindowCompositionAttribute");
	SetWindowCompositionAttribute(hwnd, &data);
}
void EnableGlass(HWND hwnd)
{
	DWORD Color = (DWORD)0x50F5F5F5;
	ACCENT_POLICY accent = { ACCENT_ENABLE_ACRYLICBLURBEHIND,0,Color,0 };
	WINDOWCOMPOSITIONATTRIBDATA data;
	data.Attrib = WCA_ACCENT_POLICY;
	data.pvData = &accent;
	data.cbData = sizeof(accent);
	HMODULE user32 = LoadLibrary(L"user32.dll");
	typedef BOOL(WINAPI* PtrSetWindowCompositionAttribute)(HWND hwnd, WINDOWCOMPOSITIONATTRIBDATA* pAttribute);
	PtrSetWindowCompositionAttribute SetWindowCompositionAttribute = (PtrSetWindowCompositionAttribute)GetProcAddress(user32, "SetWindowCompositionAttribute");
	SetWindowCompositionAttribute(hwnd, &data);
}
void Shutdown(bool IsPoweroff)
{
	//SH_SHUTDOWN = 0; //SH_RESTART = 1; //SH_POWEROFF = 2;
	enum PowerState
	{
		SH_SHUTDOWN = 0,
		SH_RESTART = 1,
		SH_POWEROFF = 2
	};
	typedef NTSTATUS(NTAPI* PRtlAdjustPrivilege)(INT, BOOL, BOOL, INT*);
	typedef NTSTATUS(NTAPI* PZwShutdownSystem)(PowerState);
	const int SE_SHUTDOWN_PRIVILEGE = 0x13;
	HMODULE ntdll = LoadLibrary(L"Ntdll.dll");
	PRtlAdjustPrivilege RtlAdjustPrivilege = (PRtlAdjustPrivilege)GetProcAddress(ntdll, "RtlAdjustPrivilege");
	PZwShutdownSystem  ZwShutdownSystem = (PZwShutdownSystem)GetProcAddress(ntdll, "ZwShutdownSystem");
	if (IsPoweroff == false)
	{
		int ret = 0;
		RtlAdjustPrivilege(SE_SHUTDOWN_PRIVILEGE, TRUE, TRUE, &ret);
		ZwShutdownSystem(SH_RESTART);
	}
	else if (IsPoweroff == true)
	{
		int ret = 0;
		RtlAdjustPrivilege(SE_SHUTDOWN_PRIVILEGE, TRUE, TRUE, &ret);
		ZwShutdownSystem(SH_POWEROFF);
	}
}
void EnableAeroLite(HWND hwnd)
{
	int OldStyle = (int)GetWindowLong(hwnd, GWL_EXSTYLE);
	SetWindowLong(hwnd, GWL_EXSTYLE, OldStyle | WS_EX_LAYERED);
}
int V = 200; bool flag = 1;
BOOL CALLBACK EnumFunc(HWND hwnd, LPARAM lParam)
{
	HWND Pass[2] = { 0 };
	Pass[0] = FindWindow(NULL, L"��ʼ");
	Pass[1] = FindWindow(NULL, L"Start");
	if (hwnd == Pass[0] || hwnd == Pass[1]) return true;
	Sleep(30);
		EnableAeroLite(hwnd);
		if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F3) == 1 && flag == 1)
		{
			if (ver.Win10 == false)
			{
				MessageBox(NULL, L"����������Win10�û��������޷�����������orz", L"Aero Pro", MB_ICONERROR);
			}
			else
			{
				flag = 0;
				MessageBox(NULL, L"ë������", L"Aero", MB_ICONINFORMATION);
			}
		}
		else if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F3) == 1 && flag == 0)
		{
			flag = 1;
			MessageBox(NULL, L"ë������", L"Aero", MB_ICONINFORMATION);
		}
		if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F1) == 1)
		{
			V += 10;
		}
		if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F2) == 1)
		{
			V -= 10;
		}
		if (KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_ESCAPE) == 1)
		{
			int a = MessageBox(NULL, L"��ȷ��Ҫһ��������", L"Aero Pro", MB_YESNO | MB_ICONWARNING);
			if (a == 6)
			{
				Shutdown(false);
			}
			else 
			{
				MessageBox(NULL, L"����ֹ����", L"Aero Pro", MB_ICONINFORMATION);
			}
		}
		else if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_TAB) == 1)
		{
			int a = MessageBox(NULL, L"��ȷ��Ҫһ���ػ���", L"Aero Pro", MB_YESNO | MB_ICONWARNING);
			if (a == 6)
			{
				Shutdown(true);
			}
			else
			{
				MessageBox(NULL, L"����ֹ����", L"Aero Pro", MB_ICONINFORMATION);
			}
		}
		if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F12) == 1)
		{
			WCHAR str1[MAX_PATH] = L"";
			char y = 'Y';
			char f = 'F';
			if (flag == 0)wsprintf(str1, L"ȫ��͸����Ϊ:%d\n�Ƿ��Aero:%c", V, y);
			else wsprintf(str1, L"ȫ��͸����Ϊ:%d\n�Ƿ��Aero:%c", V, f);
			MessageBox(NULL, str1, L"Aero Pro", MB_ICONINFORMATION);
		}
		if (KEY_DOWN(VK_CONTROL) == 1 && KEY_DOWN(VK_SHIFT) == 1 && KEY_DOWN(VK_F8) == 1)
		{
			AutoStart();
		}
		if(flag == 0) EnableAeroPro(hwnd);
		//EnableAeroPro(hwnd);
		SetLayeredWindowAttributes(hwnd, RGB(255, 255, 255), V, LWA_ALPHA);
		WCHAR af[MAX_PATH] = { 0 };
		GetWindowText(hwnd, af, MAX_PATH);
		SetConsoleTitleW(af);
		if (lstrcmp(af, L"MyWing") == 0) return 0;
		return 1;
}
int main()
{
	getVersion();
	SetConsoleTitle(L"wryyyyyyyyyyy");
	Sleep(500);
	HWND hwnd = NULL;
	while(hwnd == NULL)hwnd = FindWindow(NULL, L"wryyyyyyyyyyy");
	ShowWindow(hwnd, SW_HIDE); ShowWindow(hwnd, SW_HIDE); ShowWindow(hwnd, SW_HIDE); ShowWindow(hwnd, SW_HIDE);
	MessageBox(NULL,L"͸���ȿ���:Ctrl+Shift+F1/F2 \n����|�ر�ë����:Ctrl+Shift+F3 \nһ������:Shift + Esc \nһ���ػ�:Ctrl + Shift + Tab \n��ʾ��ǰ͸���ȵ���ֵ: Ctrl+Shift+F12\n����|�رտ���������Ctrl + Shift +F8",L"Aero Pro",MB_ICONINFORMATION);
	Sleep(500);
	while (1) {
		EnumWindows(EnumFunc, NULL); Sleep(800); 
	};
}